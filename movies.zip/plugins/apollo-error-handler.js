export default function(err) {
    console.error(err);
}
