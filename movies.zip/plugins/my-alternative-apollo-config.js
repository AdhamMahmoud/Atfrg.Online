export default function (context) {
  return {
    httpEndpoint: 'https://us1.prisma.sh/shady-khalifa/aflam-club/dev',
    getAuth: () => 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7InNlcnZpY2UiOiJhZmxhbS1jbHViQGRldiIsInJvbGVzIjpbImFkbWluIl19LCJpYXQiOjE1ODE0MzYwMDAsImV4cCI6MjE0NTkxNjgwMH0.lNaFMz-2KGPIFipp58VYR_SJuoVwrNkj2S91euzdFmo'
  }
}
